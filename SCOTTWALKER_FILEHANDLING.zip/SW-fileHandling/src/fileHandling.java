import java.io.File;  // importing the File class
import java.io.IOException;  // importing the IOException class in order to handle errors
import java.io.FileWriter;   // importing the FileWriter class
import java.util.Scanner; // importing the Scanner class to be able to read text files
import java.io.FileNotFoundException;  //  this default class handles errors

public class fileHandling {
  public static void main(String[] args) {
    try {
      File myFile = new File("ScottsFile.txt"); //creating new file
      if (myFile.createNewFile()) 
      {
        System.out.println("File was successfully created: " + myFile.getName()); 
        // getName is a predefined method of the file class
      } else {
        System.out.println("File already exists."); // error msg
      }
    } catch (IOException e) {
      System.out.println("An error occurred."); // error msg
      e.printStackTrace(); // print error details
    }
   
  try {
	  //CREATING FILE & ADDING TXT TO IT
      FileWriter newText = new FileWriter("filename.txt");
      newText.write("Adding some words to the new file...");
      newText.close(); //closing the file
      System.out.println("Successfully wrote to the file.");
    } catch (IOException x) { //in case it isn't able to write, print error msg
      System.out.println("Uh-oh an error has occurred /-:");
      x.printStackTrace(); //print error details
    }
  
  try { // THIS BLOCK READS THE FILE CREATED ABOVE
      File myFile = new File("ScottsFile.txt");
      Scanner myReader = new Scanner(myFile);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("Uh-oh an error has occurred /-:");
      e.printStackTrace(); // prints error details
    }
  }
	}